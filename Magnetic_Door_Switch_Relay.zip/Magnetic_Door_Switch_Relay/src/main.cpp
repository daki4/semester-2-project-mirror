#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
// Long Cable is pos(+)
// Short Cable is neg(-)

int REEDSWITCH = 4; // pin NUM
bool previousDoorStatus = HIGH;

const char *ssid = "Daki4-pixel6";
const char *password = "mmmpiidau";
const char *mqttServer = "mqtt.yordanmitev.me";
const int mqttPort = 1883;
const char *mqttUser = "3dPrinterUsr";
const char *mqttPassword = "somepassword";

WiFiClient espClient;
PubSubClient client(espClient);

void tryToConccet()
{
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }

  Serial.println("Connected to the WiFi network");

  client.setServer(mqttServer, mqttPort);

  while (!client.connected())
  {
    Serial.println("Connecting to MQTT...");

    if (client.connect("ESP32Client", mqttUser, mqttPassword))
    {

      Serial.println("connected");
    }
    else
    {

      Serial.print("failed with state ");
      Serial.print(client.state());
      delay(2000);
    }
  }
}
void setup()
{
  Serial.begin(9600);
  WiFi.begin(ssid, password);
  tryToConccet();
  pinMode(REEDSWITCH, INPUT_PULLUP);
}

bool getDoorStatus()
{

  bool StatusDoor = digitalRead(REEDSWITCH);
  return StatusDoor;
}
void loop()
{

  bool doorStatus = getDoorStatus();
  String doorString = String(getDoorStatus());
  client.publish("3dPrinter/1/Door/", doorString.c_str());

  if (doorStatus != previousDoorStatus)
  {
    previousDoorStatus = doorStatus;

    if (doorStatus == HIGH)
    {
      Serial.println("Door is OPEN! ");
    }
    else
    {
      Serial.println("Door is Closed. ");
    }
  }

  delay(100);
}