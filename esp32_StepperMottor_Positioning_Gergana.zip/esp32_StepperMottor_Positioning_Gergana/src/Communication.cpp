#include <Arduino.h>
#include "Communication.h"
String ReadMessage()
{
  char inputBuffer[64];
  String inputString;
  if (Serial.available() > 0)
  {                                                              // check if there is incoming serial data
                                                                 // create a buffer to store the input string
    int numChars = Serial.readBytesUntil('\n', inputBuffer, 63); // read a complete string until newline is received
    inputBuffer[numChars] = '\0';                                // add null terminator at the end of the string
    inputString = inputBuffer;                                   // convert the char array to a String
                                                                 // print the input string to the serial monitor
  }
  return inputString;
}
