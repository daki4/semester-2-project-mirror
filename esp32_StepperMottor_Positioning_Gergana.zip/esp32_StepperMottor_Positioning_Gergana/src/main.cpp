#include <Arduino.h>
#include <WiFi.h>
#include <AccelStepper.h>
#include <PubSubClient.h>
#include "StepperMottor.h"



// UPDATE - Setting absolute and relative position
//  TO DO - finish the other atributes and connect to C#/ fix the connection to the server


char message;
const char *ssid = "Daki4-pixel6";                  // NAME OF THE WIFI
const char *password = "parola112";             // THE PASSWORD OF THE WIFI
const char *mqttServer = "mqtt.yordanmitev.me"; // LINK TO THE SERVER
const int mqttPort = 1883;                      // PORT
const char *mqttUser = "3dPrinterUsr";          // USERNAME FOR THE SERVER
const char *mqttPassword = "somepassword";      // SERVER PASSWORD

WiFiClient espClient;
PubSubClient client(espClient);

void callback(char *topic, byte *payload, unsigned int length)
{

  Serial.print("Message arrived in topic: ");
  Serial.println(topic);

  Serial.print("Message:");
  for (int i = 0; i < length; i++)
  {
    message = (char)payload[i];
    Serial.print(message);
  }

  Serial.println();
  Serial.println("-----------------------");
}

void setup()
{
  Serial.begin(9600);

  InitializeSteppers();

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }

  Serial.println("Connected to the WiFi network");

  client.setServer(mqttServer, mqttPort);
    client.setCallback(callback);

  while (!client.connected()) {
    Serial.println("Connecting to MQTT...");

    if (client.connect("ESP32Client", mqttUser, mqttPassword )) {

      Serial.println("connected");

    } else {

      Serial.print("failed with state ");
      Serial.print(client.state());
      delay(2000);

    }
  }
   client.subscribe("test");
  client.publish("test", "Hello from ESP32");
}

void loop()
{

  client.loop();
  work();

}