#include <Arduino.h>
#include "StepperMottor.h"
#include <AccelStepper.h>
#include "Communication.h"

AccelStepper stepperX(AccelStepper::FULL4WIRE, IN1_X, IN3_X, IN2_X, IN4_X);
AccelStepper stepperY(AccelStepper::FULL4WIRE, IN1_Y, IN3_Y, IN2_Y, IN4_Y);
AccelStepper stepperZ(AccelStepper::FULL4WIRE, IN1_Z, IN3_Z, IN2_Z, IN4_Z);

bool relativePosition = true;
bool absolutePosition = false;
int startPositionX = 0;
int EndPositionX = 2010;
int startPositionY = 0;
int EndPositionY = 2010;
int startPositionZ = 0;
int EndPositionZ = 2010;
unsigned long currentTime;

String command;

void InitializeSteppers()
{

    stepperX.setMaxSpeed(SPEED);
    stepperX.setAcceleration(ACCELERATION);
    stepperY.setMaxSpeed(SPEED);
    stepperY.setAcceleration(ACCELERATION);
    stepperZ.setMaxSpeed(SPEED);
    stepperZ.setAcceleration(ACCELERATION);
    obeyCommands();
    if (absolutePosition)
    {
        setAbsolutePositionsX(startPositionX, EndPositionX);
        setAbsolutePositionsY(startPositionY, EndPositionY);
        setAbsolutePositionsZ(startPositionZ, EndPositionZ);
    }
    else if (relativePosition)
    {
        setRelativePositionsX(startPositionX, EndPositionX);
        setRelativePositionsY(startPositionY, EndPositionY);
        setRelativePositionsZ(startPositionZ, EndPositionZ);
    }
   
    
}

void work()
{
    if (stepperX.distanceToGo() != 0)
    {
        stepperX.run();
    }
    if (stepperY.distanceToGo() != 0)
    {
        stepperY.run();
    }
    if (stepperZ.distanceToGo() != 0)
    {
        stepperZ.run();
    }
    printPosition();
}
void printPosition()
{
    if (millis() - currentTime >= INTERVAL)
    {
        currentTime = millis();
        Serial.printf("Current position of X: %d\n", stepperX.currentPosition());
        Serial.printf("Current position of Y: %d\n", stepperY.currentPosition());
        Serial.printf("Current position of Z: %d\n", stepperZ.currentPosition());
    }
}
void obeyCommands()
{   Serial.println("Waiting for command");
    command = ReadMessage();

    if (command == "r")
    {
        relativePosition = true;
        absolutePosition = false;
    }
    else if (command == "a")
    {
        relativePosition = false;
        absolutePosition = true;
    }
}

void setAbsolutePositionsX(int startPos, int endPos)
{
    stepperX.setCurrentPosition(startPos);
    if (endPos <= MAX_POS)
    {
        stepperX.moveTo(endPos);
    }
}
void setAbsolutePositionsY(int startPos, int endPos)
{
    stepperY.setCurrentPosition(startPos);
    if (endPos <= MAX_POS)
    {
        stepperY.moveTo(endPos);
    }
}

void setAbsolutePositionsZ(int startPos, int endPos)
{
    stepperZ.setCurrentPosition(startPos);
    if (endPos <= MAX_POS)
    {
        stepperZ.moveTo(endPos);
    }
}

void setRelativePositionsX(int startPos, int endPos)
{
    stepperX.setCurrentPosition(startPos);
    if (endPos <= MAX_POS)
    {
        stepperX.move(endPos);
    }
}
void setRelativePositionsY(int startPos, int endPos)
{
    stepperY.setCurrentPosition(startPos);
    if (endPos <= MAX_POS)
    {
        stepperY.move(endPos);
    }
}

void setRelativePositionsZ(int startPos, int endPos)
{
    stepperZ.setCurrentPosition(startPos);
    if (endPos <= MAX_POS)
    {
        stepperZ.move(endPos);
    }
}
