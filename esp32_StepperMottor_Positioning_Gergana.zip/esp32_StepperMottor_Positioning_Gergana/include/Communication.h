#ifndef CONNECTION_H
#define CONNECTION_H
#include <Arduino.h>
String ReadMessage();

#endif