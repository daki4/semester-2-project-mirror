#ifndef  STEPPER_MOTTROR_H
#define STEPPER_MOTTOR_H
#include <AccelStepper.h>
#define MIN_POS 0
#define MAX_POS 2010
#define SPEED 100
#define ACCELERATION 20
#define INTERVAL 1000
#define IN1_X 19
#define IN2_X 18
#define IN3_X 5
#define IN4_X 17

#define IN1_Y 2
#define IN2_Y 15
#define IN3_Y 32
#define IN4_Y 33

#define IN1_Z 26
#define IN2_Z 27
#define IN3_Z 14
#define IN4_Z 12


void InitializeSteppers();
void work(); 
void obeyCommands();
void setAbsolutePositionsX(int startPos, int endPos);
void setAbsolutePositionsY(int startPos, int endPos);
void setAbsolutePositionsZ(int startPos, int endPos);
void setRelativePositionsX(int startPos, int endPos);
void setRelativePositionsY(int startPos, int endPos);   
void setRelativePositionsZ(int startPos, int endPos);
void printPosition();


#endif