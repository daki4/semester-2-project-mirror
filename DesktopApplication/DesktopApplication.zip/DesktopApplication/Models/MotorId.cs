﻿namespace PrinterApplication.Models;
public enum MotorId
{
    X,
    Y,
    Z,
}
